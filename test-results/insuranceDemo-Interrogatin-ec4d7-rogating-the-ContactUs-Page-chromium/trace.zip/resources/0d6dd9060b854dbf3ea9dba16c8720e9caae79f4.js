var banner_slider; 

$(document).ready(function() {
	$('.tt').click(function(event) {
		event.preventDefault();
	});
	
	$('li.dropdown').on('mouseenter mouseleave', function(e) {
		if ($('ul', this).length) {
			var elm = $('ul:first', this);
			var off = elm.offset();
			var navoff = $('#navigation').offset();
			var l = off.left - navoff.left;
			var w = elm.width();
			// var docH = $('#navigation').height();
			var docW = $('#navigation').width();
			
			var isEntirelyVisible = (l + w <= docW+2);
			
			if (! isEntirelyVisible) {
				$('.dropdown-menu', this).css('left', '-'+(l+w-docW)+'px');
				$(this).addClass('edge');
			}
		}
	});

	$('form[name="quick_quote"]').submit(function(e) {
		if (! $(this).attr('action').includes('secureformsolutions')) {
			e.preventDefault();
			window.location=$(this).attr('action');
		}
	});
	
	if (typeof($JssorSlider$) != 'undefined' && $JssorSlider$ !== null) {
		var _CaptionTransitions = [];
		_CaptionTransitions["L"] = { $Duration: 800, x: 0.6, $Easing: { $Left: $JssorEasing$.$EaseInOutSine }, $Opacity: 2 };
		_CaptionTransitions["R"] = { $Duration: 800, x: -0.6, $Easing: { $Left: $JssorEasing$.$EaseInOutSine }, $Opacity: 2 };
		_CaptionTransitions["T"] = { $Duration: 800, y: 0.6, $Easing: { $Top: $JssorEasing$.$EaseInOutSine }, $Opacity: 2 };
		_CaptionTransitions["B"] = { $Duration: 800, y: -0.6, $Easing: { $Top: $JssorEasing$.$EaseInOutSine }, $Opacity: 2 };
		_CaptionTransitions["TL"] = { $Duration: 800, x: 0.6, y: 0.6, $Easing: { $Left: $JssorEasing$.$EaseInOutSine, $Top: $JssorEasing$.$EaseInOutSine }, $Opacity: 2 };
		_CaptionTransitions["TR"] = { $Duration: 800, x: -0.6, y: 0.6, $Easing: { $Left: $JssorEasing$.$EaseInOutSine, $Top: $JssorEasing$.$EaseInOutSine }, $Opacity: 2 };
		_CaptionTransitions["BL"] = { $Duration: 800, x: 0.6, y: -0.6, $Easing: { $Left: $JssorEasing$.$EaseInOutSine, $Top: $JssorEasing$.$EaseInOutSine }, $Opacity: 2 };
		_CaptionTransitions["BR"] = { $Duration: 800, x: -0.6, y: -0.6, $Easing: { $Left: $JssorEasing$.$EaseInOutSine, $Top: $JssorEasing$.$EaseInOutSine }, $Opacity: 2 };
		_CaptionTransitions["MCLIP|B"] = { $Duration: 600, $Clip: 8, $Move: true, $Easing: $JssorEasing$.$EaseOutExpo };
		_CaptionTransitions["Z"] = { $Duration:900, $Zoom:1, $Easing:$JssorEasing$.$EaseInCubic, $Opacity:2};
	
		var options = { 
			$AutoPlay: true,
			$SlideDuration: jsOptions.SlideDuration,
			$AutoPlayInterval: jsOptions.AutoPlayInterval,
			$ArrowNavigatorOptions: {
				$AutoCenter: jsOptions.ArrowNavigatorOptions.AutoCenter,
				$Class: $JssorArrowNavigator$,
				$ChanceToShow: 1
			},
			$BulletNavigatorOptions: {
				$Class: $JssorBulletNavigator$,
				$ChanceToShow: 2,
				$AutoCenter: jsOptions.BulletNavigatorOptions.AutoCenter,
				$SpacingX: 10,
				$SpacingY: 10
			},
			$CaptionSliderOptions: {
				$Class: $JssorCaptionSlider$,
				$CaptionTransitions: _CaptionTransitions,
				$PlayInMode: 1,
				$PlayOutMode: 3
			}
		};
		if ($('#banner_slider').length) {
			banner_slider = new $JssorSlider$('banner_slider', options);
		}
		
		// Responsive slider option
		function ScaleSlider() {
			if ($('#banner_slider').length) {
				var parentWidth = $('#banner_slider').parent().width();
				if (parentWidth) {
					banner_slider.$ScaleWidth(parentWidth);
				} else {
					window.setTimeout(ScaleSlider, 30);
				}
			}
		}
		
		ScaleSlider();
		$(window).bind('load', ScaleSlider);
		$(window).bind('resize', ScaleSlider);
		$(window).bind('orientationchange', ScaleSlider);
	}
	
	if (navigator.userAgent.match(/(iPod|iPhone|iPad)/)) {
		$(window).scrollTop();
		$('html,body').scrollTop();
		var dragging = false;
		
		$('a').on('touchmove', function() {
			dragging = true;
		});
		
		$('a').on('click touchend', function(e) {
			if (dragging) {
				return;
			}
			var el = $(this);
			var link = el.attr('href');
			window.location = link;
		});
		
		$('a').on('touchstart', function() {
			dragging = false;
		});
	}
	
    var pathname = window.location.href;
    $('a').each(function () {
		if ($(this)[0].hasAttribute('href')) {
			var link = $(this).attr('href');
			if (link.substr(0,1) === "#") {
				$(this).attr('href', pathname + link);
			}
		}
    });
    
    $(document).on("keydown", ":input:not(textarea):not(:submit)", function(event) {
        if (event.key == "Enter") {
            event.preventDefault();
        }
    });
});

function PauseSlider() {
	if ($('#banner_slider').length) {
		banner_slider.$Pause();
	}
}



// Form Scripts
function showDiv(divName,lastDiv,moreDiv,lessDiv,hideLess) {
	document.getElementById(divName).className = "visibleDiv";
	document.getElementById(lastDiv).className = "upper_div";
	document.getElementById(moreDiv).className = "hiddenDiv";
	document.getElementById(lessDiv).className = "visibleDiv";
	document.getElementById(hideLess).className = "hiddenDiv";
}
function hideDiv(divName,lastDiv,moreDiv,lessDiv,showLess) {
	document.getElementById(divName).className = "hiddenDiv";
	document.getElementById(lastDiv).className = "visibleDiv";
	document.getElementById(moreDiv).className = "visibleDiv";
	document.getElementById(lessDiv).className = "hiddenDiv";
	document.getElementById(showLess).className = "visibleDiv";
}
function ShowMenu(num, menu, max) 
{ 
	for(i = 1; i <= num; i++){ 
		var menu2 = menu + i; 
		document.getElementById(menu2).style.display = 'block'; 
	} 
	var num2 = num; num2++; 
	while(num2 <= max){
		var menu3 = menu + num2; 
		document.getElementById(menu3).style.display = 'none'; 
		num2=num2+1; 
	} 
}
var digits = "0123456789";
var phoneNumberDelimiters = "()- ";
var validWorldPhoneChars = phoneNumberDelimiters + "+";
var minDigitsInIPhoneNumber = 10;
function isInteger(s)
{   var i;
	for (i = 0; i < s.length; i++)
	{   
		var c = s.charAt(i);
		if (((c < "0") || (c > "9"))) return false;
	}
	return true;
}
function trim(s)
{   var i;
	var returnString = "";
	for (i = 0; i < s.length; i++)
	{   
		var c = s.charAt(i);
		if (c != " ") returnString += c;
	}
	return returnString;
}
function stripCharsInBag(s, bag)
{   var i;
	var returnString = "";
	for (i = 0; i < s.length; i++)
	{   
		var c = s.charAt(i);
		if (bag.indexOf(c) == -1) returnString += c;
	}
	return returnString;
}
function checkInternationalPhone(strPhone){
	var bracket=3
	strPhone=trim(strPhone)
	if(strPhone.indexOf("+")>1) return false
	if(strPhone.indexOf("-")!=-1)bracket=bracket+1
	if(strPhone.indexOf("(")!=-1 && strPhone.indexOf("(")>bracket)return false
	var brchr=strPhone.indexOf("(")
	if(strPhone.indexOf("(")!=-1 && strPhone.charAt(brchr+2)!=")")return false
	if(strPhone.indexOf("(")==-1 && strPhone.indexOf(")")!=-1)return false
	s=stripCharsInBag(strPhone,validWorldPhoneChars);
	return (isInteger(s) && s.length >= minDigitsInIPhoneNumber);
}

function checkZip(strZip){
	return (isInteger(strZip) && strZip.length == 5);
}
function echeck(str) {
	var at="@"
	var dot="."
	var lat=str.indexOf(at)
	var lstr=str.length
	var ldot=str.indexOf(dot)
	if (str.indexOf(at)==-1){
	   return false
	}
	if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
	   return false
	}
	if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		return false
	}
	 if (str.indexOf(at,(lat+1))!=-1){
		return false
	 }
	 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		return false
	 }
	 if (str.indexOf(dot,(lat+2))==-1){
		return false
	 }
	 if (str.indexOf(" ")!=-1){
		return false
	 }
	 return true					
}
function checkVals()
{
	document.forms['form1'].fname.style.background='#ffffff';
	document.forms['form1'].lname.style.background='#ffffff';
	document.forms['form1'].email.style.background='#ffffff';
	document.forms['form1'].phone.style.background='#ffffff';
	document.forms['form1'].zip.style.background='#ffffff';
	var flag=0;
	var alert_focus="";
	var emailID=document.forms['form1'].email;
	var alert_text="Please fill in all of the required information.  We pledge to never sell or share your personal information.  Review our privacy policy for more info.\n\nThe following information is missing...\n\n";
	
	if(document.forms['form1'].fname.value == ""){
		var flag=1;
		var alert_text = alert_text+"Your First and Last Name\n";
		if(alert_focus == '') var alert_focus="fname";
		document.forms['form1'].fname.style.background='#cee8eb';
	}
	
	if(document.forms['form1'].lname.value == ""){
		var flag=1;
		if(document.forms['form1'].fname.value != "") var alert_text = alert_text+"Your First and Last Name\n";
		if(alert_focus == '') var alert_focus="lname";
		document.forms['form1'].lname.style.background='#cee8eb';
	}
	
	if (echeck(document.forms['form1'].email.value)==false && checkInternationalPhone(document.forms['form1'].phone.value)==false){
		var flag=1;
		var alert_text = alert_text+"A Valid Email Address OR A Valid Phone Number\n";
		if(alert_focus == '') var alert_focus="email";
		document.forms['form1'].email.style.background='#cee8eb';
		document.forms['form1'].phone.style.background='#cee8eb';
	}
	
	if (checkZip(document.forms['form1'].zip.value)==false){
		var flag=1;
		var alert_text = alert_text+"A Five Digit Zip Code\n";
		if(alert_focus == '') var alert_focus="zip";
		document.forms['form1'].zip.style.background='#cee8eb';
	}
	
	if(flag==1){
		alert(alert_text);
		document.getElementById(alert_focus).focus();
		return (false);
	}else{
		return (true);
	}

}
function checkQQ()
{
	document.forms['quick_quote'].qq_fname.style.background='#ffffff';
	document.forms['quick_quote'].qq_lname.style.background='#ffffff';
	document.forms['quick_quote'].qq_email.style.background='#ffffff';
	document.forms['quick_quote'].qq_phone.style.background='#ffffff';
	document.forms['quick_quote'].qq_zip.style.background='#ffffff';
	var flag=0;
	var alert_focus="";
	var emailID=document.forms['quick_quote'].qq_email;
	var alert_text="Please fill in all of the required information.  We pledge to never sell or share your personal information.  Review our privacy policy for more info.\n\nThe following information is missing...\n\n";
	
	if(document.forms['quick_quote'].qq_fname.value == ""){
		var flag=1;
		var alert_text = alert_text+"Your First and Last Name\n";
		if(alert_focus == '') var alert_focus="qq_fname";
		document.forms['quick_quote'].qq_fname.style.background='#cee8eb';
	}
	
	if(document.forms['quick_quote'].qq_lname.value == ""){
		var flag=1;
		if(document.forms['quick_quote'].qq_fname.value != "") var alert_text = alert_text+"Your First and Last Name\n";
		if(alert_focus == '') var alert_focus="qq_lname";
		document.forms['quick_quote'].qq_lname.style.background='#cee8eb';
	}
	
	if (echeck(document.forms['quick_quote'].qq_email.value)==false && checkInternationalPhone(document.forms['quick_quote'].qq_phone.value)==false){
		var flag=1;
		var alert_text = alert_text+"A Valid Email Address OR A Valid Phone Number\n";
		if(alert_focus == '') var alert_focus="qq_email";
		document.forms['quick_quote'].qq_email.style.background='#cee8eb';
		document.forms['quick_quote'].qq_phone.style.background='#cee8eb';
	}
	
	if (checkZip(document.forms['quick_quote'].qq_zip.value)==false){
		var flag=1;
		var alert_text = alert_text+"A Five Digit Zip Code\n";
		if(alert_focus == '') var alert_focus="qq_zip";
		document.forms['quick_quote'].qq_zip.style.background='#cee8eb';
	}
	
	if(flag==1){
		alert(alert_text);
		document.getElementById(alert_focus).focus();
		return (false);
	}else{
		return (true);
	}

}

!function(a){"function"==typeof define&&define.amd?define(["jquery"],a):a("object"==typeof module&&module.exports?require("jquery"):jQuery)}(function(a){function b(b){var c={},d=/^jQuery\d+$/;return a.each(b.attributes,function(a,b){b.specified&&!d.test(b.name)&&(c[b.name]=b.value)}),c}function c(b,c){var d=this,f=a(d);if(d.value==f.attr("placeholder")&&f.hasClass(m.customClass))if(f.data("placeholder-password")){if(f=f.hide().nextAll('input[type="password"]:first').show().attr("id",f.removeAttr("id").data("placeholder-id")),b===!0)return f[0].value=c;f.focus()}else d.value="",f.removeClass(m.customClass),d==e()&&d.select()}function d(){var d,e=this,f=a(e),g=this.id;if(""===e.value){if("password"===e.type){if(!f.data("placeholder-textinput")){try{d=f.clone().attr({type:"text"})}catch(h){d=a("<input>").attr(a.extend(b(this),{type:"text"}))}d.removeAttr("name").data({"placeholder-password":f,"placeholder-id":g}).bind("focus.placeholder",c),f.data({"placeholder-textinput":d,"placeholder-id":g}).before(d)}f=f.removeAttr("id").hide().prevAll('input[type="text"]:first').attr("id",g).show()}f.addClass(m.customClass),f[0].value=f.attr("placeholder")}else f.removeClass(m.customClass)}function e(){try{return document.activeElement}catch(a){}}var f,g,h="[object OperaMini]"==Object.prototype.toString.call(window.operamini),i="placeholder"in document.createElement("input")&&!h,j="placeholder"in document.createElement("textarea")&&!h,k=a.valHooks,l=a.propHooks;if(i&&j)g=a.fn.placeholder=function(){return this},g.input=g.textarea=!0;else{var m={};g=a.fn.placeholder=function(b){var e={customClass:"placeholder"};m=a.extend({},e,b);var f=this;return f.filter((i?"textarea":":input")+"[placeholder]").not("."+m.customClass).bind({"focus.placeholder":c,"blur.placeholder":d}).data("placeholder-enabled",!0).trigger("blur.placeholder"),f},g.input=i,g.textarea=j,f={get:function(b){var c=a(b),d=c.data("placeholder-password");return d?d[0].value:c.data("placeholder-enabled")&&c.hasClass(m.customClass)?"":b.value},set:function(b,f){var g=a(b),h=g.data("placeholder-password");return h?h[0].value=f:g.data("placeholder-enabled")?(""===f?(b.value=f,b!=e()&&d.call(b)):g.hasClass(m.customClass)?c.call(b,!0,f)||(b.value=f):b.value=f,g):b.value=f}},i||(k.input=f,l.value=f),j||(k.textarea=f,l.value=f),a(function(){a(document).delegate("form","submit.placeholder",function(){var b=a("."+m.customClass,this).each(c);setTimeout(function(){b.each(d)},10)})}),a(window).bind("beforeunload.placeholder",function(){a("."+m.customClass).each(function(){this.value=""})})}});
//# sourceMappingURL=jquery.placeholder.min.js.map

$('input, textarea').placeholder();